        <ul id="MenuBar1" class="MenuBarHorizontal">
           <li><a href="main.php">Home</a>
          	<ul>
              <li><a href="">Slideshow</a>
                <ul>
                  <li><a href="add_slide.php">Add</a></li>
                  <li><a href="view_slide.php">View</a></li>                  
                </ul>
              </li>
			  <li><a href="">Tag Line</a>
                <ul>
                  <li><a href="edit_tagline.php">Edit</a></li>                  
                </ul>
              </li>
             </ul> 
             <li><a href="">Categories</a>
                <ul> 
                  <li><a href="">Category</a>
                  <ul>
                  <li><a href="add_category.php">Add</a></li>
				  <li><a href="view_category.php">View</a></li>
                  </ul>
                  </li>     
				  <li><a href="">Sub Category</a>
                  <ul>
                  <li><a href="add_subcategory.php">Add</a></li>
				  <li><a href="view_subcategory.php">View</a></li>
                  </ul>
                  </li>     
                </ul>
			 </li>
           </li>
          <li><a href="">Products</a>
          	<ul>
            <li><a href="">Products</a>
            <ul>
            <li><a href="add_product.php">Add</a></li>
            <li><a href="view_product.php">View</a></li>
            </ul>
            </li>
            </ul>
          </li>
		  <li><a href="">Orders</a>
          	<ul>
            <li><a href="">Order</a>
            <ul>
            <li><a href="view_order.php">View</a></li>
            </ul>
            </li>            
            </ul>
          </li>
</ul> 
        <!-- Menu Ends-->
        <script type="text/javascript">
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"SpryAssets/SpryMenuBarDownHover.gif", imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
</script>