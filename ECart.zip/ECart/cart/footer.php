  		</div>
        <div class="footer">
        	<div style="float:left; width:300px;" ><p>&copy; 2016, All rights reserved by E Cart</p></div>
            <div style="float:right; width:300px; margin-right:45px; " ></div>
        </div>
        </div> 
        <div class="page-bottom"></div>
   	</div>
</div>
</body>
</html>