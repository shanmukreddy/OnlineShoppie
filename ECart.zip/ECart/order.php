<?php session_start();
include('includes/dbconnect.php');
if(isset($_SESSION['id']))
{
$id=$_GET['id'];
}
 if(isset($_SESSION['user']))
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | ECart</title>
   <?php include 'includes/header.php'; ?>
<style>
	.hide-menu
	{
		
/*display:none ;*/
	}
	ul#cbp-hrmenu, #cbp-hrmenu ul  {
list-style-type: none;
margin: 0;
padding: 0;
}

#cbp-hrmenu li {
/* float: left;   */
}
#cbp-hrmenu {
	/*width:80%;*/
	width:auto;
}
@media screen and (min-width:768px) and (max-width:1024px) {
#cbp-hrmenu {
	/*width:80%;*/
	width:auto;
}
}

#cbp-hrmenu a:visited {
}
#cbp-hrmenu a:link, div.horizontal a:visited {

}
#cbp-hrmenu a {
display: block;
    
}

#cbp-hrmenu a:hover {
}

#cbp-hrmenu li.hideshow ul{
position:absolute;
background: #f3f3f3;
display:none;
left:0px;
z-index:9999;

}

#cbp-hrmenu li.hideshow
{
position:relative;
}

@media(max-width:767px) {
	
#cbp-hrmenu li.hideshow ul{
position:relative;
float:left;	
}
}
	</style>
    <script>
	function alignMenu() {
		var w = 0;
		var mw = $("#cbp-hrmenu").width() - 150;
		var i = -1;
		var menuhtml = '';
		jQuery.each($("#cbp-hrmenu").children(), function() {
			i++;
			w += $(this).outerWidth(true);
			if (mw < w) {
				menuhtml += $('<span>').append($(this).clone()).html();
				$(this).remove();
			}
		});
		$("#cbp-hrmenu").append(
				'<li  style="position:relative;" href="#" class="hideshow">'
						+ '<a href="#">more '
						+ '<span style="font-size:14px">&#8595;</span>'
						+ '</a><ul>' + menuhtml + '</ul></li>');
		$("#cbp-hrmenu li.hideshow ul").css("top",
				$("#horizontal li.hideshow").outerHeight(true) + "px");
		$("#cbp-hrmenu li.hideshow").click(function() {
			$(this).children("ul").toggle();
		});
		if (menuhtml == '') {
			$("#cbp-hrmenu li.hideshow").hide();
		} else {
			$("#cbp-hrmenu li.hideshow").show();
		}
		//$("#cbp-hrmenu").removeClass('hide-menu');
	}
	$(function() {
    alignMenu();
	
    $(window).resize(function() {
      $("#cbp-hrmenu").append($("#cbp-hrmenu li.hideshow ul").html());
        $("#cbp-hrmenu li.hideshow").remove();
        alignMenu();
    });
	
	});
	
	</script>
	<style type="text/css">
.items_bg {
	margin-top: 10px !important;
}
.my-cart {
	margin-top: 10px !important;
}
.wishlist_name_wish {
	background-color: #086EC4;
	color: #fff;
}
.sort_items .bootstrap-select {
	background-color: #f3f3f3 !important;
	-webkit-border-top-left-radius: 4px;
	-webkit-border-top-right-radius: 4px;
	-moz-border-radius-topleft: 4px;
	-moz-border-radius-topright: 4px;
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
	border: 1px solid #f3f3f3;
}
.sort_items .bootstrap-select .btn .caret {
	color: #646464;
}
.sort_items .bootstrap-select .btn {
	padding-top: 5px !important;
	padding-bottom: 5px !important;
}
.bootstrap-select {
	width: 100%;
	float: left;
	background-color: #f3f3f3;
	color: #555;
}
.btn-arrow {
}

.nice-select .list {
	background-color: #fff;
	width:100%;
	min-width:180px;
	float:left;
	border-radius: 0px;
	box-shadow: 0 0 0 1px rgba(68, 88, 112, 0.11);
	box-sizing: border-box;
	margin-top: 1px;
	opacity: 0;
	height:200px;
	overflow: hidden;
	overflow-y:scroll;
	padding: 0;
	pointer-events: none;
	position: absolute;
	top: 100%;
	left: 0;
	-webkit-transform-origin: 50% 0;
	transform-origin: 50% 0;
	-webkit-transform: scale(0.75) translateY(-21px);
	transform: scale(0.75) translateY(-21px);
	transition: all 0.2s cubic-bezier(0.5, 0, 0, 1.25), opacity 0.15s ease-out;
	/*z-index: 9000;*/
	z-index: 99;
}

</style>

<!--/head-->

<body>
<section>
<div class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<div id="wrapper"> 
          <!-- Middle page -->
			<?php	//checking the shipping and the final order review button variables if they are not set the page will display the products in the cart
					if(!isset($_REQUEST["shipping"]) AND !isset($_REQUEST["final_order"]))
					{?>
		<!--Start fo the code for showing items in Cart-->
					<div class="middle">
						<div class="header-heading">
							<h1>Items in your cart <a href="index.php">Continue Shopping</a></h1>
						</div>
						<div class="row">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
											<!-- Modal content-->
									<div class="row">
										<?php 
										$deliver_charge = 0; //initializing the valiable
										$user = $_SESSION['user']; // fetching user information from session variable
										$res=mysql_query("SELECT c.*,p.* from products p,cart c where p.id=c.productid and c.email='$user'");
										$count=mysql_num_rows($res); // counting the num of rows fetched
										if($count>0)   // check to find the entries
										{
											while($row=mysql_fetch_array($res)) //looping the rows fetched
											{
											?>
											<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="no_items">
												<div class="items_bg data_qty_check" id="data_check_300" data-check="0">
													<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
														<div class="img-width"> 
															<!--Populating Image-->
															<img src="cart/product/<?php echo $row['image_url']?>" alt="<?php echo $row['name']?>" class="img-responsive" /> 
														</div>
													</div>
													<div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
														<div class="item-heading">
															<!--Populating the product name-->
															<h1><a href="#"><?php echo $row['name']?></a></h1>
															<p>In Stock</p>
															<!---->
															<p> 
																<a href="delete_product_cart.php?id=<?php echo $row['productid']?>" onclick="return conf();" class="remove_this">
																Remove
																</a>
																<a href="to_wishlist.php?id=<?php echo $row['id']?>&page=order.php" class="wish_this">
																Wishlist
																</a>
															</p>
														</div>
													</div>
													<div class="col-xs-12 col-sm-2 col-md-2 col-lg-2">
														<div class="qty">
															<h2><strong>Quantity</strong> <span></span>
															</h2>
															<div class="box1">
																<div class="qty2">
																	  <select id="qty<?php echo $row['productid']?>" prod="<?php echo $row['productid']?>">
																	  <option value="1">1</option>
																	  <option value="2">2</option>
																	  <option>3</option>
																	  <option>4</option>
																	  <option>5</option>
																	  <option>6</option>
																	  <option>7</option>
																	  <option>8</option>
																	  <option>9</option>
																	  <option>10</option>
																	</select>
																</div>
															</div>
														</div>
													</div>
													<script>
													$("#qty<?php echo $row['productid']?>").change(function () {
														var prod = $('#qty<?php echo $row['productid']?>').attr("prod");
														var str = $('#qty<?php echo $row['productid']?>').val();
														var upri = $("#produ"+prod).attr("unit_price");
														var pri = upri * str;
														var price = '$'+pri+'.00';
														$('div.produ'+prod).text(price);
														$('div.produi'+prod).text(str);
														$.post("qty.php", {product:prod,price:pri,uprice:upri,qtyval:$(this).val()});
													  })
													  .change();
													</script>
													<div class="col-xs-12 col-sm-2 col-md-2 col-lg-2">
														<div class="price">
															<h3><strong>Price</strong></h3>
															<div id="produ<?php echo $row['productid']?>" class="produ<?php echo $row['productid']?>" unit_price="<?php echo $row['price']?>">$<?php echo $row['price']?>.00</div>
														</div>
													</div>
													<p id="qtyerr_300" style="color:red; text-align:center;width:100%;float:left;margin-bottom:0px;padding-bottom:0px;">
													</p>
												</div>
											</div>
										<?php 
											} 
											$cartitems = '';
										}
										else
										{?>
										<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="no_items">
											<div class="items_bg data_qty_check" id="data_check_300" data-check="0">
												<?php 
												echo "No items in the cart";
												$cartitems = '1';
												?>
											</div>
										</div>
										<?php
										}?>
									</div>
								</div>
								<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<?php if($cartitems != '1') 
									{?>
									<div class="my-cart">
									<h2>Order Summary</h2>
										<div class="mycart-items">
											<ul>
												<li class="mycart-items-li-first mycart-items-li-header">&nbsp;&nbsp;Item</li>
												<li class="mycart-items-li-second mycart-items-li-header">Qty</li>
												<li class="mycart-items-li-third mycart-items-li-header">Price</li>
											</ul>
											<ul id="li_cart_300">	
											<?php 
													$deliver_charge = 0;
												$resu=mysql_query("SELECT c.*,p.* from products p,cart c where p.id=c.productid and c.email='$user'");
												$cou=mysql_num_rows($resu);
												if($cou>0)
												{
													while($row1=mysql_fetch_array($resu))
													{
													$deliver_charge = $deliver_charge + $row1['delivery_charge'];
													?>
													<li class="mycart-items-li-first">
													<?php echo substr($row1['name'],0,15);
													?></li>
													<li class="mycart-items-li-second" id="produ<?php echo $row1['productid']?>">
														<div id="produi<?php echo $row1['productid']?>" class="produi<?php echo $row1['productid']?>" unit_price="<?php echo $row1['price']?>">
														1
														</div>
													</li>
													<li class="mycart-items-li-third to_price " id="price_<?php echo $row1['productid']?>"  data-pprice="10.00"  data-ptx="">
														<div id="produ<?php echo $row1['productid']?>" class="produ<?php echo $row1['productid']?>" unit_price="<?php echo $row1['price']?>">
														$<?php echo $row1['price']?>.00
														</div>
													</li>							
													<?php 
													}
												}?>
											</ul>
											<ul>
												<li class="mycart-items-li-first" style="border-bottom:none;">Delivery Charge:</li>
												<li class="mycart-items-li-second" style="border-bottom:none;">&nbsp;</li>
												<li class="mycart-items-li-third" style="border-bottom:none;"><strong>$<span id="delivery_charge"><?php echo $deliver_charge;?>.00</span></strong></li>
											</ul>
										</div>
										<form action="">
											<button class="checkout" type="submit" name="shipping">
												Checkout
											</button>
										</form>
									</div>
									<?php } ?>
								</div>
							</div>
						</div>
					<!-- Middle page end --> 
					</div>
				  <!--End fo the code for showing items in Cart-->
			<?php 	} 
					else 
					{?>
			<div class="middle">
						<?php 
						// if the final order button variable is not set then page will display to select the addresses
						if(!isset($_REQUEST["final_order"]))
						{?>
					<!--Start fo the code for showing shipping-->
						<div class="header-heading">
						  <h1>Create Shipping</h1><p>Select Address</p>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						  <div class="menu-new">
							<ul>
							  <li><a href="javascript:void(0);" class="shipping1">1. Shipping</a></li>
							  <!-- <li><a href="/order/payment" class="payment1">2. Payment</a></li> -->
							  <li><a href="javascript:void(0);" class="review1-active">2. Review & Place Order</a></li>
							</ul>
						  </div>
						</div>
						<div class="row">
						<!-- Start of the code for showing the addresses of the user-->
							<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8"> 
							<!-- Modal content-->
								<div class="items_bg_shipping">
									<div id="wrapper"> 
									<!-- Middle page -->
										<div class="shipping_data">
											<div class="row">
											<form action="" method="post" id="registrationform">
											<?php 
													$user = $_SESSION['user'];
													$sql="SELECT * from addresses where email='$user'";
													$result=mysql_query($sql);
													while($row=mysql_fetch_array($result))
													{
											?>
												<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
													<div class="address_new1">
														<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
															<h4><?php echo $row['firstname']?> &nbsp; <?php echo $row['lastname']?></h4>
															<p><?php echo $row['address1']?><?php echo $row['address2']?></p>
															<br />
															<div class="shipping_data shipping_data-1">
																<label> Select this
																<input name="address" type="radio" value="<?php echo $row['id']?>" checked class="billing_address">
																</label>
															</div>
														</div>
													</div>
												</div>
											<?php 	}?>
											</div>
											<div>
											   </br>
											</div>
											<center><a href="add_address1.php?url=order.php?shipping=" class="edit_this" name="add">New Address</a></center>
											<div>
											</br>
											</div>
										</div>
								<!-- Middle page end --> 
									</div>
								</div>
							</div>
						<!-- End of the code for showing the addresses of the user-->
				<?php 	}
						// page display to review the order
						else
						{ ?>
						<!-- Start of the code for showing the final order details -->
							<div class="header-heading">
								<h1>Create Shipping</h1> 
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="menu-new">
									<ul>
										<li><a href="javascript:void(0);" class="shipping1-active">1. Shipping</a></li>
										<li><a href="javascript:void(0);" class="review1">2. Review & Place Order</a></li>
									</ul>
								</div>
							</div>
						<div class="row">
							<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
								<!-- Modal content-->
								<div class="items_bg_shipping">
									<div id="wrapper">
									<!-- Middle page -->
										<div class="shipping_data">
											<div class="row">
												<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
													<h1>Review and Place Your Order</h1>
													<div class="select_address1">
													<?php $addressid = $_POST['address'];
													$resu=mysql_query("SELECT * from addresses where id='$addressid'");
													while($row1=mysql_fetch_array($resu))
													{
													?>
														<h3>Shipping to : <span><?php echo $row1['firstname']; echo ' '; echo $row1['lastname']; ?></span></h3>
															<div class="name-sec">
																<div class="name-left">
																	<label><span style="float:left;"><strong>Shipping Address:</strong></span>  <!-- <a href="#"><strong>Edit</strong></a> --></label>
																	<p><?php echo $row1['address1'];?> &nbsp;&nbsp;<?php echo $row1['address2'];?><br>
																	<?php echo $row1['city'];?>-<?php echo $row1['pincode'];?><br><?php echo $row1['state'];?></p>
																</div>
															</div>
											<?php 	} ?>
														<div class="name-sec">
															<div class="name-left">
																<label><span style="float:left;"><strong>Shipping Method:</strong></span>  <!-- <a href="#"><strong>Edit</strong></a> --></label>
																<p>Standard: Free</p>
															</div>
														</div>
														
													</div>
													<div class="bottom_buttons">
													</div>    
													<div class="row">    
														<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
															<p>
															<?php $addressid = $_POST['address'];?>
															<a href="to_order.php?add=<?php echo $addressid;?>" class="input_submit" id="place-order3" >Place Order</a>
															</p>
														</div>
													</div>
												</div>     
											</div>
										</div>
									<!-- Middle page end -->  
									</div>
								</div> 
							</div>
							<?php 
						}?>
						<!-- End of the code for showing the final order details -->
							<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 padding-lft">
									<div class="my-cart">
										<h2>Order Summary</h2>
										<div class="mycart-items">
											<ul>
												<li class="mycart-items-li-first mycart-items-li-header">&nbsp;&nbsp;Item</li>
												<li class="mycart-items-li-second mycart-items-li-header">Qty</li>
												<li class="mycart-items-li-third mycart-items-li-header">Price</li>
											</ul>
											<?php 
												$deliver_charge = 0;// calculating the delivery charge for the products
												$total = 0;
												$user = $_SESSION['user'];
												$resu=mysql_query("SELECT * from cart where email='$user'");
												$cou=mysql_num_rows($resu);
												if($cou>0)
												{
													while($row1=mysql_fetch_array($resu))
													{
														if($row1['quantity'] == 1)
														{
														$total = $total + $row1['price'];							
														}
														else
														{
														$total = $total + $row1['total_price'];							
														}
														$deliver_charge = $deliver_charge + $row1['delivery_charge'];
														?>
														<ul id="li_cart_300">
															<li class="mycart-items-li-first"><?php echo $row1['name']?></li>
															<li class="mycart-items-li-second" ><?php echo $row1['quantity']?></li>
															<li class="mycart-items-li-third to_price">
															$<?php 
															if($row1['quantity'] == 1)
															{
															echo $row1['price'];
															}
															else
															{
															echo $row1['total_price'];
															}?>.00</li>
														</ul>
											  <?php }
												}?>
												<ul>
													<li class="mycart-items-li-first" style="border-bottom:none;">Delivery Charge</li>
													<li class="mycart-items-li-second" style="border-bottom:none;">&nbsp;</li>
													<li class="mycart-items-li-third" style="border-bottom:none;">$<span id="delivery_charge"><?php echo $deliver_charge?>.00</span></li>
												</ul>
												<ul class="total_pro">
													<li class="mycart-items-li-first"><strong>Total:</strong></li>
													<li class="mycart-items-li-second">&nbsp;</li>
													<li class="mycart-items-li-third"><strong id="g_total1">
													$<?php $total = $total + $deliver_charge; echo $total;?>.00</strong></li>
												</ul>
										</div>
									</div>
								</div>
							</div>
							<?php if(isset($_REQUEST["shipping"]) AND !isset($_REQUEST["final_order"]))
							{
							?>
							<div class="container">
								<div class="col-xs-12 col-12 col-md-8 col-lg-8">
								<?php unset($_REQUEST["shipping"])?>
									<p><input name="final_order" type="submit" value="Continue" class="input_submit margn-botm" /></p>
								</div>
								</form>
									<div class="col-xs-12 col-12 col-md-4 col-lg-4">
									</div>
							</div>
							<?php 
							} ?>
						</div>
					</div>
				  <!-- Middle page end --> 
				<?php } ?>
			</div>
		</div>
	</div>
</div>
</section>
<!--Javascript to confirm the removal of product-->
<script type="text/javascript">
function conf()
{
	
	var r=confirm("Remove Product from the cart...?");
	if(r==true)
		{
		return true;
		}
	else
		{
		return false;
		}
}
</script>
<?php include 'includes/footer.php'; 
}
else
{
header("Location:login.php?id=$id");		
}
?>