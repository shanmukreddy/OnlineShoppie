<?php session_start();

 if(isset($_SESSION['user']))		// getting username from the session
{
include('includes/dbconnect.php');	// including the database connections
$id=$_GET['id'];		// fetching the id
$user=$_SESSION['user'];
$back="order.php";
$table="wishlist";
$title="Wishlist";
?>

        <?php
		$sql="DELETE FROM $table WHERE productid='$id' AND email='$user'";		//deleting the product from the wishlist with the help of usename and product id
		$result=mysql_query($sql);
		if($result>0)			// if the deletion is success
		{ ?>
        <script>
		window.location="wishlist.php";	//redirecting to wishlist page

			</script>
            <?php
		}
		else
		{
			echo mysql_error();?>
        	<div class="welcome">
            	<h3>Failed to delete product </h3>
                
                <p>Click Here to go <a href="<?php echo $back;?>">BACK</a></p>
            </div>
	<?php	
		}
?><?php 
}
else
{

header('Location:index.php');			// Redirecting to home page if the session is not started	
}
?>

