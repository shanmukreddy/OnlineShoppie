<!DOCTYPE html>
<?php session_start();
include('includes/dbconnect.php');
if(isset($_GET['bc']))
{
$bc=$_GET['bc'];
print '<script type="text/javascript">'; 
print 'alert("'.$bc.'")'; 
print '</script>';
}
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | E Cart</title>
<?php include 'includes/header.php';  //including header ?>
	<style>
	.hide-menu
	{
		
/*display:none ;*/
	}
	ul#cbp-hrmenu, #cbp-hrmenu ul  {
list-style-type: none;
margin: 0;
padding: 0;
}

#cbp-hrmenu li {
/* float: left;   */
}
#cbp-hrmenu {
	/*width:80%;*/
	width:auto;
}
@media screen and (min-width:768px) and (max-width:1024px) {
#cbp-hrmenu {
	/*width:80%;*/
	width:auto;
}
}

#cbp-hrmenu a:visited {
}
#cbp-hrmenu a:link, div.horizontal a:visited {

}
#cbp-hrmenu a {
display: block;
    
}

#cbp-hrmenu a:hover {
}

#cbp-hrmenu li.hideshow ul{
position:absolute;
background: #f3f3f3;
display:none;
left:0px;
z-index:9999;

}

#cbp-hrmenu li.hideshow
{
position:relative;
}

@media(max-width:767px) {
	
#cbp-hrmenu li.hideshow ul{
position:relative;
float:left;	
}
}
	</style>
    <script>
	function alignMenu() {
		var w = 0;
		var mw = $("#cbp-hrmenu").width() - 150;
		var i = -1;
		var menuhtml = '';
		jQuery.each($("#cbp-hrmenu").children(), function() {
			i++;
			w += $(this).outerWidth(true);
			if (mw < w) {
				menuhtml += $('<span>').append($(this).clone()).html();
				$(this).remove();
			}
		});
		$("#cbp-hrmenu").append(
				'<li  style="position:relative;" href="#" class="hideshow">'
						+ '<a href="#">more '
						+ '<span style="font-size:14px">&#8595;</span>'
						+ '</a><ul>' + menuhtml + '</ul></li>');
		$("#cbp-hrmenu li.hideshow ul").css("top",
				$("#horizontal li.hideshow").outerHeight(true) + "px");
		$("#cbp-hrmenu li.hideshow").click(function() {
			$(this).children("ul").toggle();
		});
		if (menuhtml == '') {
			$("#cbp-hrmenu li.hideshow").hide();
		} else {
			$("#cbp-hrmenu li.hideshow").show();
		}
		//$("#cbp-hrmenu").removeClass('hide-menu');
	}
	$(function() {
    alignMenu();
	
    $(window).resize(function() {
      $("#cbp-hrmenu").append($("#cbp-hrmenu li.hideshow ul").html());
        $("#cbp-hrmenu li.hideshow").remove();
        alignMenu();
    });
	
	});
	
	</script>
	
	 <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/jquery.feedBackBox.css" rel="stylesheet" type="text/css">

    <link href="assets/css/owl.theme.css" rel="stylesheet">
<script src="assets/js/jquery.validate.min.js"></script>
 <script src="assets/js/jquery.feedBackBox.js"></script>
<style type="text/css">
.searchBox{
  background-image:url('assets/images/button.png');
  font-style: italic;
}
.sort_items .bootstrap-select {
	background-color: #ffffff !important;
	-webkit-border-top-left-radius: 4px;
	-webkit-border-top-right-radius: 4px;
	-moz-border-radius-topleft: 4px;
	-moz-border-radius-topright: 4px;
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
	border: 1px solid #f3f3f3;
}
.sort_items .bootstrap-select .btn .caret {
	color: #646464;
}
.sort_items .bootstrap-select .btn {
	padding-top: 5px !important;
	padding-bottom: 5px !important;
}
.bootstrap-select {
	width: 100%;
	float: left;
	background-color: #f3f3f3;
	color: #555;
}
#fancybox-close {
	display: none;
}
#please_wait_div
{
color:green;
}
</style>
<style type="text/css">
.item {
	float: left;
	position: relative;
}
.item-hover,  .item-hover .mask,  .item-img {
	position: absolute;
	left: 0;
	width: 100%
}
.item-type-double .item-hover {
	z-index: 1999;
	-webkit-transition: all 300ms ease-out;
	-moz-transition: all 300ms ease-out;
	-o-transition: all 300ms ease-out;
	transition: all 300ms ease-out;
	opacity: 0;
	cursor: pointer;
	display: block;
	text-decoration: none;
	text-align: center;
	width: 100%;
	float: left;
}
.item-type-double .item-info {
	z-index: 10;
	color: #ffffff;
	display: table-cell;
	vertical-align: middle;
	position: relative;
	z-index: 1999;
	width: 100%;
	float: left;
	margin-top: 60px;
}
.item-type-double .item-info .headline {
	font-size: 20px;
	width: 90%;
	margin: 0 auto;
}
.item-type-double .item-info .line {
	height: 2px;
	width: 0%;
	margin: 15px auto;
	background-color: #ffffff;
	-webkit-transition: all 300ms ease-out;
	-moz-transition: all 300ms ease-out;
	-o-transition: all 300ms ease-out;
	transition: all 300ms ease-out;
}
.item-type-double .item-info .date {
	font-size: 17px;
}
.item-type-double .item-hover .mask {
	background-color: #000;
	-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)";
	filter: alpha(opacity=50);
	opacity: 0.6;
	z-index: 1998;
	-webkit-border-top-left-radius: 4px;
	-webkit-border-top-right-radius: 4px;
	-moz-border-radius-topleft: 4px;
	-moz-border-radius-topright: 4px;
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
}
.item-type-double .item-hover:hover .line {
	width: 90%;
}
.item-type-double .item-hover:hover {
	opacity: 1;
}
.item-img {
	z-index: 0;
}
.msg
{
color:red;
}
</style>

<body class="fbits-home">
<section class="slider1"> 
	<div class="home">
		<div class="span12">
            <div id="owl-demo" class="owl-carousel">
			<?php 
				$sql="SELECT * from home_slide";
				$result=mysql_query($sql);
				while($row=mysql_fetch_array($result))
				{ ?>
                <div class="item1"> <img src="cart/slides/<?php echo $row['image_url']?>" alt="<?php echo $row['title']?>" title="" border="0" /></div>
				<?php } ?>
            </div>
        </div>
	</div>
</section>
<section>
	<div class="container">
		<div class="row">
			<div class="category-tab1">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<ul>
						<div class="row">
							<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<h1>Top Products</h1>
							</div>
						</div>
					</ul>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 padding-right">
			<div class="features_items">
<!--features_items-->
				<div class="tab-content">
					<div class="tab-panesss fade in" id="traditional" category="traditional">
					<div class="row">
						<?php 
						//Query to fetch the products and limit 15 is to limit the products upto 15.
						$sql="SELECT * from products ORDER by RAND() limit 15";
						$result=mysql_query($sql);
						while($row=mysql_fetch_array($result))
						{ ?>
							<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 tab-pane" id="296" category="<?php echo $row['category']?>" price="<?php echo $row['price']?>">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo text-center">
											<div class="item item-type-double">
												<div class="item-hover">
													<div class="item-info">
														<div class="date">
														<!--onClick in below line triggers the script to add to wishlist-->														
														<a href="javascript:void(0);" onClick="to_wishlist(<?php echo $row['id']?>);" class="wishlist_name">Wishlist</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
														<a href="product.php?id=<?php echo $row['id']?>">View</a>
														</div>
														<div class="line"></div>
														<!--onClick in below line triggers the script to add to cart-->
														<div class="headline"><a href="javascript:void(0);" onClick="to_cart(<?php echo $row['id']?>);"> Add to cart</a></div>
														<div class="line"></div>
													</div> 
													<div class="mask"></div> 
												</div> 
														<!--below is to display the product image-->
												<div class="item-img"> <img src="cart/product/<?php echo $row['image_url']?>" alt="<?php echo $row['name']?>"  class="img-responsive"></div> 
											</div>
										</div>
									</div>
								</div>
								<!--below is to display the product name and price-->
								<div class="choose"><h2><span><?php echo substr($row['name'],0,22)?></span><p>$<?php echo $row['price']?></p></h2>
								</div>
							</div>
				<?php 	} ?>      
					</div>
<script> <!-- Jquery to add items to cart -->
function to_cart(val) {
	$.ajax({
	type: "POST",
	url: "to_cart.php",
	data:'id='+val,
	success: function(data){
		$("#item_count").html(data);
	}
	});
}
</script>
<script> <!-- Jquery to add items to wishlist -->
function to_wishlist(id) {   
	$.ajax({
	type: "POST",
	url: "to_wishlist.php",
	data:'id='+id,
	success: function(data){
		$("#wishlist_count").html(data);
	}
	});
}
</script>
					</div>
				</div>
			</div>
</section>
<!-- Modal -->
		</div>

<style> 
  #owl-demo .item1 img{
        display: block;
        width: 100%;
        height: auto;
    }
</style>
  <script src="assets/js/owl.carousel.js"></script>
  <script>
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
      autoPlay: 3000,
      navigation : false,
      slideSpeed : 300,
      //paginationSpeed : 400,
      singleItem : true
     });
    });
	function refreshimage()
	{
	var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 7; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));
         $("#cap").val('');
	 $("#someid").val(text);
	 $("#someidd").val(text);
	 
	}
    </script>
<?php include 'includes/footer.php'; ?>