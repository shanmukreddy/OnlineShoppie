   <link rel="stylesheet" href="assets/css/style.css"> 
   <link href="assets/css/bootstrap.min.css" rel="stylesheet">
   <link href="assets/css/font-awesome.min.css" rel="stylesheet">
<!--    <link href="assets/fonts.css" rel="stylesheet">
-->	<link href="assets/css/main.css" rel="stylesheet">
	<link href="assets/css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" media="all" href="assets/css/prettyPhoto.css" />
	<link rel="stylesheet" type="text/css" media="all" href="assets/css/price-range.css" />
	<link rel="stylesheet" type="text/css" media="all" href="assets/css/animate.css" />
    <link rel="stylesheet" type="text/css" media="all" href="assets/css/liquid-slider.css" />
	<link rel="stylesheet" type="text/css" media="all" href="assets/css/bootstrap-select.css" />
<link rel="stylesheet" type="text/css" media="all" href="assets/css/inr-stylesheet.css" />
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->  
   
    <script src="assets/js/jquery.js"></script>
    
	<script src="assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap-select.js"></script>
	<script type="text/javascript" src="assets/js/allscript.js"></script>
	<link href="assets/css/local.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="assets/js/jquery.liquid-slider.min.js"></script>
    
	<script type="text/javascript" src="assets/js/jquery.validate.min.js"></script>
    	
	<script src="assets/js/bootbox.min.js"></script>    	
    <style type='text/css'>@import url('http://getbarometer.s3.amazonaws.com/assets/barometer/css/barometer.css');</style>
<script src='http://getbarometer.s3.amazonaws.com/assets/barometer/javascripts/barometer.js' type='text/javascript'></script>
<script type="text/javascript" charset="utf-8">
  BAROMETER.load('Z1pea5b8AeQfPmegNyxcL');
</script>
</head><!--/head-->
<header id="header"><!--header-->
	<div class="header_top"><!--header_top-->
			<div class="container">
            <div class="bottom_border">
				<div class="row">					
					 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
                            <div class="row">
								<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<?php $sql="SELECT * from tagline";
										$result=mysql_query($sql);
										while($row=mysql_fetch_array($result))
										{ ?>
									<?php echo $row['tagline']?>
									<?php }
									 if(isset($_SESSION['user']))
									{?>
									<li>
        		 <div class="box3">
			
            <select name="Myaccount" id="myaccount">
                        <option  value="myaccount" data-display="My Account" >My Account</option>
			<option value="orders" data-display="My Account" >Orders</option> 
			<option value="changepass" data-display="My Account" >Change Password</option>			
            <option value="logout" data-display="My Account" >Logout</option>			
            </select>
			 <script>
			 $(document).ready(function(){
				 $('#myaccount').change(function(){
					 $option=$(this).val();
					 switch($option)
					 {
						 case 'logout':
						 {
							  window.location='signout.php';
							  break;
						 }
						 case 'myaccount':
						 {
							  window.location='myaccount.php';
							  break;
						 }
						 case 'orders':
						 {
							  window.location='myorders.php';
							  break;
						 }
						case 'changepass':
						{
						 window.location='changepassword.php';
						 break;
						}
						 default:
						 {
							 
						 }
					 }
					 /* if($option=='logout')
					 {
						 window.location='/home/logout';
					 }
					 else
					 {
						 window.location='/home/myaccount';
					 } */
				 });
			 });
			 </script>
            </div>
          </li><?php } 
		  else
		  { ?>
		  
		  						<li>
										<div class="login_box1">
										<a href="signup.php"><img src="assets/images/signup.png" alt="signup" width="20px" height="20px">Signup</a>
										</div>
										<div class="login_box">
											<a href="login.php"><img src="assets/images/login.png" alt="login" width="20px" height="20px"> Login</a>
										</div>
									</li>
									
			<?php } ?>
									<li>
								<?php 
								
								// to populate the total no of item in wishlist
								$wishlist_count = 0;
								if(isset($_SESSION['user']))
								{
								$user = $_SESSION['user'];
								$wishlist=mysql_query("SELECT * from wishlist where email = '$user'");
								$wishlist_count=mysql_num_rows($wishlist);
								}	?>									
										<a href="wishlist.php"><img src="assets/images/wishlist.png" alt="wishlist" width="20px" height="20px">Wishlist (<span id="wishlist_count"><?php echo $wishlist_count;?></span>)</a>
									</li>
								</div>
                            </div>
							</ul>
						</div>
					</div>
				</div>
			</div>
            </div>
		</div>	
        		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-xs-6 col-sm-3 col-md-3 col-lg-3">
						<div class="logo pull-left">
							<a href="index.php"><img src="assets/images/home/logo.png" alt="Logo" width="160px" height="150px" alt="" class="img-responsive" /></a>
						</div>
					</div>
                  
					<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9 pull-right">
                    <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                      <div class="row">
                      <form action="products.php" method="post">
                      <div class="col-xs-12 col-sm-9 col-md-9 col-lg-9 select_all1">
                     <div class="select_all">
                      <div class="box">
                    
					<select name="category" id="category" >
							<option>All</option>
                    <?php 
					// Fetch the categories for dropdown
						$sql="SELECT * from categories";
						$result=mysql_query($sql);
						while($row=mysql_fetch_array($result))
						{ ?>
							<option value="<?php echo $row['name']?>"><?php echo $row['name']?></option> 
						<?php } ?>
					</select>
                    
					</div>
                    </div>
                    
                     <div id="custom-search-input">
					        <div class="input-group col-md-12">
							    <input type="text" class="earch-query form-control"  name="search" id="search" placeholder="Search" />
                                <span class="input-group-btn">
                                    <button class="btn btn-danger btn-arrow" type="submit" id='search_val'>
                                     <img src="assets/images/Search-icon.png" alt="search" width="20px" height="20px">
                                    </button>
                                </span>
						    </div>
						</div>
                        </div>
                        </form>
                        </div>
                    </div>
					</div>
                    </div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
                
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse cbp-hrmenu hide-menu" id="cbp-hrmenu">
							<?php 
							// fetch the categories for menu
								$cat="SELECT * from categories";
								$catres=mysql_query($cat) or die(mysql_error());
									while($row=mysql_fetch_array($catres))
										{ ?>
										<li><a href="products.php?cat=<?php echo $row['name']?>" id="<?php echo $row['id']?>"><?php echo $row['name']?></a></li>
										<?php 
										} 
								?>
							</ul>
							
                            <div class="view_cart">
                            <?php 
							// fetch the data of total products in cart
								$item_count = 0;
								if(isset($_SESSION['user']))
								{
								$user = $_SESSION['user'];
								$item=mysql_query("SELECT * from cart where email = '$user'");
								$item_count=mysql_num_rows($item);
								}	?>
                            <a href="order.php"> <img src="assets/images/home/add.png" alt="cart" width="25" height="20"> Cart (<span id="item_count"><?php echo $item_count ?></span>)</a>
							
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->