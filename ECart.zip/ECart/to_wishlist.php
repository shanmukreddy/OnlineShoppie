<?php
session_start();
		if(isset($_GET['id']))
		{
		$id=$_GET['id'];
		$page=$_GET['page'];
		}
		else
		{
		$id=$_POST['id'];
		}

if(!isset($_SESSION['user']))
	{
		header("Location:login.php");		
	}
else
	{
		include('includes/dbconnect.php');
		$tbl_name="wishlist"; // Table name

		
		$user=$_SESSION['user'];
		$sql1= mysql_query("SELECT * FROM $tbl_name WHERE email='$user' and productid='$id'");
		$count=mysql_num_rows($sql1);

		if($count==0)
		{
			$sql="INSERT INTO $tbl_name (email,productid) values ('$user','$id')";
			$result=mysql_query($sql);

			if($result>0)
				{
					$del = mysql_query("DELETE FROM cart WHERE email = '$user' AND productid = '$id'");
					if(!isset($_GET['id']))
					{
					$result=mysql_query("SELECT * from wishlist where email = '$user'");
					$count=mysql_num_rows($result);
					echo $count;
					$msg = "Product is added to your wishlist";
					print '<script type="text/javascript">'; 
					print 'alert("'.$msg.'")'; 
					print '</script>';
					}
					else
					{
					$msg = "Product added to your wishlist";
					$page=$_GET['page'];
					header("location:$page?id=$id&bc=$msg");
					}
				}
		}
		else 
			{ 
				if(!isset($_GET['id']))
				{
				$result=mysql_query("SELECT * from wishlist where email = '$user'");
				$count=mysql_num_rows($result);
				$msg = "Product is already present in your wishlist";
				print '<script type="text/javascript">'; 
				print 'alert("'.$msg.'")'; 
				print '</script>';
				echo $count;
				}
				else
				{
				$msg = "Product is already present in your wishlist";
				$page=$_GET['page'];
				header("location:$page?id=$id&bc=$msg");
				}
			}

	}
?>