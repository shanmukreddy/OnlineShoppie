<?php
session_start();
// this page is to add a product to the cart
if(!isset($_SESSION['user']))
	{
		header("Location:login.php?id=$id");		
	}
else
	{
		include('includes/dbconnect.php');
		$tbl_name="cart"; // Table name
		if(isset($_GET['id']))
		{
		$id=$_GET['id'];
		$page=$_GET['page'];
		}
		else
		{
		$id=$_POST['id'];
		}
		$user=$_SESSION['user'];
		$sql1= mysql_query("SELECT * FROM cart WHERE email='$user' and productid='$id'"); // checking if the product is already present in the cart?
		$count=mysql_num_rows($sql1);

		if($count==0) // if not
		{	
			$pname= mysql_query("SELECT * FROM products WHERE id='$id'");// update to the table
			while($row=mysql_fetch_array($pname))
			{	
			$name			=	$row['name'];
			$image			=	$row['image_url'];
			$delivery_time	=	$row['delivery_time'];
			$delivery_charge=	$row['delivery_charge'];
			$price			=	$row['price'];
			$quantity		=	'1';
			}
			$sql="INSERT INTO cart (email,productid,name,quantity,delivery_charge,price,delivery_time,total_price,image) values ('$user','$id','$name','$quantity','$delivery_charge','$price','$delivery_time','$price','$image')";
			$result=mysql_query($sql);
			if($result>0)
			{
			
				$del = mysql_query("DELETE FROM wishlist WHERE email = '$user' AND productid = '$id'");// once added to cart delete the product from the wishlist table
				if(!isset($_GET['id']))
				{
				$result=mysql_query("SELECT * from cart where email = '$user'");
				$count=mysql_num_rows($result);
				echo $count; // Send the count to the header where the item in the cart are shown
				$msg = "Product is added to your cart"; // alert on the screen once it is success
				print '<script type="text/javascript">'; 
				print 'alert("'.$msg.'")'; 
				print '</script>';
				}
				else
				{
				$msg = "Product added to your cart";
				$page=$_GET['page'];
				header("location:$page?id=$id&bc=$msg");
				}
			}
		}
		else 
			{ 
				if(!isset($_GET['id']))
				{
				$result=mysql_query("SELECT * from cart where email = '$user'");
				$count=mysql_num_rows($result);
				echo $count;
				$msg = "Product is already present in your cart";
				print '<script type="text/javascript">'; 
				print 'alert("'.$msg.'")'; 
				print '</script>';
				}
				else
				{
				$msg = "Product is already present in your cart";
				$page=$_GET['page'];
				header("location:$page?id=$id&bc=$msg");
				}
			}

	}
?>