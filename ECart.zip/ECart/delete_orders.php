<?php session_start();

 if(isset($_SESSION['user']))	// getting usernam from the session
{
include('includes/dbconnect.php');  // including the database connections
$id=$_GET['id'];	// fetching the id
$back="myorders.php";
$table="orders";
$title="Address";
?>

        <?php
		$sql="DELETE FROM $table WHERE orderid='$id'";	//deleting the order from the database
		$result=mysql_query($sql);
		if($result>0)			// if the deletion is success
		{ ?>
        <script>
		window.location="myorders.php";			//redirecting to myorders page

			</script>
            <?php
		}
		else
		{
			echo mysql_error();?>
        	<div class="welcome">
            	<h3>Failed to delete order </h3>
                
                <p>Click Here to go <a href="<?php echo $back;?>">BACK</a></p>
            </div>
	<?php	
		}
?><?php 
}
else
{

header('Location:index.php');			// Redirecting to home page if the session is not started
}
?>
